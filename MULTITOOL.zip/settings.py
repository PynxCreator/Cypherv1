
#This is the config system aka settings.
delay = 0.7
Loader = "False"
Banner = "True"
ssh = "enter ssh ip"
AsciiText = "False"
token = "enter token"
#PLEASE NOTE THESE CONFIG OPTIONS GOING DOWN ARE FOR TESTING AND DO NOT TYPE "True" WHEN YOU DONT KNOW WHAT YOUR DOING
forkbomb = "False"
addtostartup = "False"
