import twint

# Configure
c = twint.Config()
c.Username = "Elonmusk"
c.Limit = 1

# Run
twint.run.Search(c)