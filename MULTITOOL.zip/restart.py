import time
import os
print("Restarting CypherServer in [5 sec]")
time.sleep(5)
os.system('python3 main.py')
os.system('clear')