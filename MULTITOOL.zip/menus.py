
tttt = ("""(31) Ascii art generator
(32) Uninstall itself (note this is not stoppable)
(33) """)
ttt = ("""(21) Run nmap scan
(22) Create ncat listener
(23) VirusMaker.v1
(24) Run reddit scraper
(25) Install Ghost sploit
(26) Install CamHackers
(27) Twitter Scraper (you need your own api)
(28) Discord nuker (you need your own token)
(29) IP Lookup
(30) Run pyautogui (Discord SelfBot Spammer)
(xx) Next page
(?) Why did i make this time consuming tool""")
tt = ("""(11) Open shodain
(12) Launch 'whois' 
(13) Open my discord server
(14) Open my youtube channel
(15) Open my twitch account
(16) Website bruteforce
(17) Install Raven-Software
(18) Install Recon
(19) Install Sherlock
(20) Open my website
(x) Next Page
(-) Back to first page
(?) Why did i kae this time consuming tool""")
t = ("""(1) Run dos tool
(2) Run bash command
(3) Enter ssh mode
(4) Port Scan
(5) URl Portscan
(6) Exit
(7) Clear
(8) Restart CypherServer
(9) Password checker
(10) Download my hacking tools
(+) Page 2
type "enter" for credit
(?) why did i make this time consuming tool.
""")