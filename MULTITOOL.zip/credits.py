def credits():
  print("Dos tool was made by a good friend named lynx")
  print("Reddit scraper made by lynx")
  print("Discord nuker made by: https://github.com/n0vuh/nuker")